
function loadData() {
    return tourismData;
}

document.addEventListener('DOMContentLoaded', function() {
    const data = loadData();
    

    const hamburger = document.querySelector('.hamburger');
    const navMenu = document.querySelector('.nav-menu');
    
    if (hamburger) {
        hamburger.addEventListener('click', () => {
            navMenu.classList.toggle('active');
        });
    }


    loadPageContent(data);
});

function loadPageContent(data) {
    const currentPage = window.location.pathname.split('/').pop() || 'index.html';
    
    switch(currentPage) {
        case 'index.html':
        case '':
            loadHomePage(data);
            break;
        case 'diem-den.html':
            loadDestinations(data.destinations);
            break;
        case 'am-thuc.html':
            loadCuisine(data.cuisine);
            break;
        case 'le-hoi.html':
            loadFestivals(data.festivals);
            break;
        case 'tour.html':
            loadTours(data.tours);
            break;
        case 'khach-san.html':
            loadHotels(data.hotels);
            break;
        case 'nha-hang.html':
            loadRestaurants(data.restaurants);
            break;
    }
}


function loadHomePage(data) {

    const destinationsContainer = document.getElementById('featuredDestinations');
    if (destinationsContainer) {
        destinationsContainer.innerHTML = data.destinations.slice(0, 6).map(dest => `
            <div class="card clickable-card" onclick="showDestinationDetails(${dest.id})">
                <img src="${dest.image}" alt="${dest.name}">
                <div class="card-content">
                    <h3>${dest.name}</h3>
                    <p><i class="fas fa-map-marker-alt"></i> ${dest.location}</p>
                    <p>${dest.description}</p>
                    <button class="btn-primary">Xem chi tiết</button>
                </div>
            </div>
        `).join('');
    }


    const cuisineContainer = document.getElementById('featuredCuisine');
    if (cuisineContainer) {
        cuisineContainer.innerHTML = data.cuisine.slice(0, 4).map(food => `
            <div class="card">
                <img src="${food.image}" alt="${food.name}">
                <div class="card-content">
                    <h3>${food.name}</h3>
                    <p>${food.description}</p>
                    <p class="price">${food.price}</p>
                </div>
            </div>
        `).join('');
    }


    const festivalsContainer = document.getElementById('featuredFestivals');
    if (festivalsContainer) {
        festivalsContainer.innerHTML = data.festivals.slice(0, 4).map(festival => `
            <div class="card clickable-card" onclick="showFestivalDetails(${festival.id})">
                <img src="${festival.image}" alt="${festival.name}">
                <div class="card-content">
                    <h3>${festival.name}</h3>
                    <p><i class="fas fa-calendar"></i> ${festival.date}</p>
                    <p><i class="fas fa-map-marker-alt"></i> ${festival.location}</p>
                    <p>${festival.description}</p>
                    <button class="btn-primary">Xem chi tiết</button>
                </div>
            </div>
        `).join('');
    }
}


function loadDestinations(destinations) {
    const container = document.getElementById('destinationsList');
    if (container) {
        container.innerHTML = destinations.map(dest => `
            <div class="card clickable-card" onclick="showDestinationDetails(${dest.id})">
                <img src="${dest.image}" alt="${dest.name}">
                <div class="card-content">
                    <h3>${dest.name}</h3>
                    <p><i class="fas fa-map-marker-alt"></i> ${dest.location}</p>
                    <p>${dest.description}</p>
                    <button class="btn-primary">Xem chi tiết</button>
                </div>
            </div>
        `).join('');
    }
}


function loadCuisine(cuisine) {
    const container = document.getElementById('cuisineList');
    if (container) {
        container.innerHTML = cuisine.map(food => `
            <div class="card">
                <img src="${food.image}" alt="${food.name}">
                <div class="card-content">
                    <h3>${food.name}</h3>
                    <p>${food.description}</p>
                    <p class="price">${food.price}</p>
                </div>
            </div>
        `).join('');
    }
}


function loadFestivals(festivals) {
    const container = document.getElementById('festivalsList');
    if (container) {
        container.innerHTML = festivals.map(festival => `
            <div class="card clickable-card" onclick="showFestivalDetails(${festival.id})">
                <img src="${festival.image}" alt="${festival.name}">
                <div class="card-content">
                    <h3>${festival.name}</h3>
                    <p><i class="fas fa-calendar"></i> ${festival.date}</p>
                    <p><i class="fas fa-map-marker-alt"></i> ${festival.location}</p>
                    <p>${festival.description}</p>
                    <button class="btn-primary">Xem chi tiết</button>
                </div>
            </div>
        `).join('');
    }
}


function loadTours(tours) {
    const container = document.getElementById('toursList');
    if (container) {
        container.innerHTML = tours.map(tour => `
            <div class="card">
                <img src="${tour.image}" alt="${tour.name}">
                <div class="card-content">
                    <h3>${tour.name}</h3>
                    <p><i class="fas fa-clock"></i> ${tour.duration}</p>
                    <p>${tour.description}</p>
                    <p class="price">${tour.price}</p>
                    <button class="btn-primary" onclick="bookTour(${tour.id})">Đặt tour</button>
                </div>
            </div>
        `).join('');
    }
}


function loadHotels(hotels) {
    const container = document.getElementById('hotelsList');
    if (container) {
        container.innerHTML = hotels.map(hotel => `
            <div class="card">
                <img src="${hotel.image}" alt="${hotel.name}">
                <div class="card-content">
                    <h3>${hotel.name}</h3>
                    <p><i class="fas fa-star"></i> ${hotel.rating} sao</p>
                    <p><i class="fas fa-map-marker-alt"></i> ${hotel.location}</p>
                    <p class="price">${hotel.price}</p>
                    <p><i class="fas fa-phone"></i> ${hotel.phone}</p>
                    <button class="btn-primary" onclick="bookHotel(${hotel.id})">Đặt phòng</button>
                </div>
            </div>
        `).join('');
    }
}


function loadRestaurants(restaurants) {
    const container = document.getElementById('restaurantsList');
    if (container) {
        container.innerHTML = restaurants.map(restaurant => `
            <div class="card">
                <img src="${restaurant.image}" alt="${restaurant.name}">
                <div class="card-content">
                    <h3>${restaurant.name}</h3>
                    <p><i class="fas fa-utensils"></i> ${restaurant.cuisine}</p>
                    <p><i class="fas fa-star"></i> ${restaurant.rating}/5</p>
                    <p>${restaurant.specialty}</p>
                    <p class="price">${restaurant.priceRange}</p>
                    <p><i class="fas fa-map-marker-alt"></i> ${restaurant.address}</p>
                    <p><i class="fas fa-phone"></i> ${restaurant.phone}</p>
                </div>
            </div>
        `).join('');
    }
}


function bookTour(tourId) {
    const data = loadData();
    const tour = data.tours.find(t => t.id === tourId);
    
    if (!tour) {
        alert('Không tìm thấy tour!');
        return;
    }
    
    const currentUser = getCurrentUser();
    let name, email;
    
    if (currentUser) {
        name = currentUser.username;
        email = currentUser.email || '';
    } else {
        name = prompt('Họ và tên:');
        if (!name) return;
        
        email = prompt('Email:');
        if (!email) return;
    }
    
    const phone = prompt('Số điện thoại:');
    if (!phone) return;
    
    const date = prompt('Ngày khởi hành (dd/mm/yyyy):');
    if (!date) return;
    
    const people = prompt('Số người tham gia:');
    if (!people) return;
    

    const bookings = JSON.parse(localStorage.getItem('tourBookings') || '[]');
    const booking = {
        id: Date.now(),
        tourId: tourId,
        tourName: tour.name,
        customerName: name,
        phone: phone,
        email: email,
        date: date,
        people: parseInt(people),
        totalPrice: tour.price,
        bookingDate: new Date().toLocaleDateString('vi-VN'),
        status: 'Đã đặt'
    };
    
    bookings.push(booking);
    localStorage.setItem('tourBookings', JSON.stringify(bookings));
    
    alert(`Đặt tour thành công!\n\nTour: ${tour.name}\nKhách hàng: ${name}\nSố người: ${people}\nNgày khởi hành: ${date}\n\nChúng tôi sẽ liên hệ với bạn sớm nhất!`);
}


function showDestinationDetails(destinationId) {
    const data = loadData();
    const destination = data.destinations.find(d => d.id === destinationId);
    
    if (!destination) {
        alert('Không tìm thấy thông tin điểm đến!');
        return;
    }
    
    // Tạo danh sách hình ảnh liên quan cho từng điểm đến
    const relatedImages = [];
    
    // Thêm hình ảnh chính
    relatedImages.push(destination.image);
    
    // Thêm 2 hình ảnh bổ sung cho từng điểm đến
    switch(destination.id) {
        case 1: // Ao Bà Om
            relatedImages.push('images/ao-ba-om-2.jpg', 'images/ao-ba-om-3.jpg');
            break;
        case 2: // Chùa Âng
            relatedImages.push('images/chua-ang-2.jpg', 'images/chua-ang-3.jpg');
            break;
        case 3: // Bảo tàng Khmer
            relatedImages.push('images/bao-tang-khmer-2.jpg', 'images/bao-tang-khmer-3.jpg');
            break;
        case 4: // Biển Ba Động
            relatedImages.push('images/bien-ba-dong-2.jpg', 'images/bien-ba-dong-3.jpg');
            break;
        case 5: // Cù lao An Bình
            relatedImages.push('images/cu-lao-an-binh-2.jpg', 'images/cu-lao-an-binh-3.jpg');
            break;
        case 6: // Văn Thánh Miếu
            relatedImages.push('images/van-thanh-mieu-2.jpg', 'images/van-thanh-mieu-3.jpg');
            break;
        case 7: // Nhà cổ Cai Cường
            relatedImages.push('images/nha-co-cai-cuong-2.jpg', 'images/nha-co-cai-cuong-3.jpg');
            break;
        case 8: // Biển Thạnh Phú
            relatedImages.push('images/bien-thanh-phu-2.jpg', 'images/bien-thanh-phu-3.jpg');
            break;
        case 9: // Làng hoa Cái Mơn
            relatedImages.push('images/lang-hoa-cai-mon-2.jpg', 'images/lang-hoa-cai-mon-3.jpg');
            break;
        case 10: // Khu du lịch Lan Vương
            relatedImages.push('images/khu-du-lich-lan-vuong-2.jpg', 'images/khu-du-lich-lan-vuong-3.jpg');
            break;
        case 11: // Vườn trái cây Bến Tre
            relatedImages.push('images/vuon-trai-cay-ben-tre-2.jpg', 'images/vuon-trai-cay-ben-tre-3.jpg');
            break;
        default:
            relatedImages.push('images/bankner-khamphaVL.jpg', 'images/bankner-khamphaVL.jpg');
    }
    
    const modal = document.createElement('div');
    modal.className = 'modal';
    modal.innerHTML = `
        <div class="modal-content">
            <span class="close" onclick="closeModal()">&times;</span>
            <div class="modal-header">
                <img src="${destination.image}" alt="${destination.name}" class="modal-image">
                <div class="modal-title">
                    <h2>${destination.name}</h2>
                    <p><i class="fas fa-map-marker-alt"></i> ${destination.location}</p>
                </div>
            </div>
            <div class="modal-body">
                <div class="detail-section">
                    <h3><i class="fas fa-info-circle"></i> Giới thiệu chi tiết</h3>
                    <p>${destination.details || destination.description}</p>
                    ${destination.history ? `
                        <div class="highlight-box">
                            <h4><i class="fas fa-history"></i> Lịch sử</h4>
                            <p>${destination.history}</p>
                        </div>
                    ` : ''}
                </div>
                
                ${destination.activities && destination.activities.length > 0 ? `
                <div class="detail-section">
                    <h3><i class="fas fa-star"></i> Hoạt động có thể tham gia</h3>
                    <ul class="activity-list">
                        ${destination.activities.map(activity => `<li>${activity}</li>`).join('')}
                    </ul>
                </div>
                ` : ''}
                
                ${relatedImages.length > 1 ? `
                <div class="detail-section">
                    <h3><i class="fas fa-images"></i> Hình ảnh</h3>
                    <div class="image-gallery">
                        ${relatedImages.slice(0, 6).map(img => `
                            <img src="${img}" alt="${destination.name}" class="gallery-image" onclick="openImageModal('${img}')">
                        `).join('')}
                    </div>
                </div>
                ` : ''}
                
                <div class="detail-info">
                    <div class="info-item">
                        <h4><i class="fas fa-clock"></i> Giờ mở cửa</h4>
                        <p>${destination.openTime || 'Cả ngày (6:00 - 18:00)'}</p>
                    </div>
                    <div class="info-item">
                        <h4><i class="fas fa-ticket-alt"></i> Giá vé</h4>
                        <p>${destination.ticketPrice || 'Miễn phí'}</p>
                    </div>
                    <div class="info-item">
                        <h4><i class="fas fa-map-marker-alt"></i> Địa chỉ</h4>
                        <p>${destination.address || destination.location}</p>
                    </div>
                    <div class="info-item">
                        <h4><i class="fas fa-phone"></i> Liên hệ</h4>
                        <p>0336160645</p>
                    </div>
                </div>
                
                <div class="related-section">
                    <h3><i class="fas fa-link"></i> Khám phá thêm</h3>
                    <div class="related-links-grid">
                        <a href="tour.html" class="related-link">
                            <i class="fas fa-route"></i>
                            <h4>Tour tham quan</h4>
                            <p>Đặt tour đến ${destination.name}</p>
                        </a>
                        <a href="khach-san.html" class="related-link">
                            <i class="fas fa-bed"></i>
                            <h4>Khách sạn gần đây</h4>
                            <p>Tìm nơi lưu trú gần ${destination.location}</p>
                        </a>
                        <a href="nha-hang.html" class="related-link">
                            <i class="fas fa-utensils"></i>
                            <h4>Nhà hàng</h4>
                            <p>Ẩm thực địa phương</p>
                        </a>
                        <a href="le-hoi.html" class="related-link">
                            <i class="fas fa-calendar"></i>
                            <h4>Lễ hội</h4>
                            <p>Lễ hội tại ${destination.location}</p>
                        </a>
                        <a href="diem-den.html" class="related-link">
                            <i class="fas fa-map-marked-alt"></i>
                            <h4>Điểm đến khác</h4>
                            <p>Khám phá thêm địa điểm</p>
                        </a>
                        <a href="lien-he.html" class="related-link">
                            <i class="fas fa-phone-alt"></i>
                            <h4>Tư vấn</h4>
                            <p>Liên hệ để được hỗ trợ</p>
                        </a>
                    </div>
                </div>
                
                <div class="action-buttons">
                    <button class="btn-action" onclick="planTrip('${destination.name}')">
                        <i class="fas fa-calendar-plus"></i> Lên kế hoạch du lịch
                    </button>
                    <button class="btn-action btn-secondary" onclick="shareDestination('${destination.name}')">
                        <i class="fas fa-share"></i> Chia sẻ
                    </button>
                    <button class="btn-action btn-secondary" onclick="getDirections('${destination.location}')">
                        <i class="fas fa-directions"></i> Chỉ đường
                    </button>
                </div>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
    modal.style.display = 'block';
    document.body.style.overflow = 'hidden';
}


function showFestivalDetails(festivalId) {
    const data = loadData();
    const festival = data.festivals.find(f => f.id === festivalId);
    
    if (!festival) {
        alert('Không tìm thấy thông tin lễ hội!');
        return;
    }
    
    // Tạo danh sách hình ảnh liên quan cho từng lễ hội
    const relatedImages = [];
    
    // Thêm hình ảnh chính
    relatedImages.push(festival.image);
    
    // Thêm 2 hình ảnh bổ sung cho từng lễ hội
    switch(festival.id) {
        case 1: // Lễ hội Ok Om Bok
            relatedImages.push('images/le-hoi-ok-om-bok-2.jpg', 'images/le-hoi-ok-om-bok-3.jpg');
            break;
        case 2: // Lễ hội Chol Chnam Thmay
            relatedImages.push('images/le-hoi-chol-chnam-thmay-2.jpg', 'images/le-hoi-chol-chnam-thmay-3.jpg');
            break;
        case 3: // Lễ hội Dừa Bến Tre
            relatedImages.push('images/le-hoi-dua-ben-tre-2.jpg', 'images/le-hoi-dua-ben-tre-3.jpg');
            break;
        case 4: // Lễ hội Văn hóa Dân gian
            relatedImages.push('images/le-hoi-van-hoa-dan-gian-2.jpg', 'images/le-hoi-van-hoa-dan-gian-3.jpg');
            break;
        case 5: // Lễ hội Cầu Ngư
            relatedImages.push('images/le-hoi-cau-ngu-2.jpg', 'images/le-hoi-cau-ngu-3.jpg');
            break;
        case 6: // Lễ hội Đền Bình Thủy
            relatedImages.push('images/le-hoi-den-binh-thuy-2.jpg', 'images/le-hoi-den-binh-thuy-3.jpg');
            break;
        case 7: // Lễ hội Nghinh Ông
            relatedImages.push('images/le-hoi-nghinh-ong-2.jpg', 'images/le-hoi-nghinh-ong-3.jpg');
            break;
        case 8: // Lễ hội Đua Bò
            relatedImages.push('images/le-hoi-dua-bo-2.jpg', 'images/le-hoi-dua-bo-3.jpg');
            break;
        default:
            relatedImages.push('images/bankner-khamphaVL.jpg', 'images/bankner-khamphaVL.jpg');
    }
    
    const modal = document.createElement('div');
    modal.className = 'modal festival-modal';
    modal.innerHTML = `
        <div class="modal-content festival-detail">
            <span class="close" onclick="closeModal()">&times;</span>
            <div class="modal-header">
                <img src="${festival.image}" alt="${festival.name}" class="modal-image">
                <div class="modal-title">
                    <h2>${festival.name}</h2>
                    <div class="festival-badges">
                        <span class="badge date-badge"><i class="fas fa-calendar"></i> ${festival.date}</span>
                        <span class="badge location-badge"><i class="fas fa-map-marker-alt"></i> ${festival.location}</span>
                        <span class="badge duration-badge"><i class="fas fa-clock"></i> ${festival.duration}</span>
                    </div>
                </div>
            </div>
            <div class="modal-body">
                <div class="festival-overview">
                    <h3><i class="fas fa-info-circle"></i> Giới thiệu</h3>
                    <p>${festival.details}</p>
                </div>
                
                <div class="festival-activities">
                    <h3><i class="fas fa-star"></i> Hoạt động chính</h3>
                    <div class="activities-grid">
                        ${festival.activities.map((activity, index) => `
                            <div class="activity-item">
                                <div class="activity-number">${index + 1}</div>
                                <div class="activity-content">
                                    <p>${activity}</p>
                                </div>
                            </div>
                        `).join('')}
                    </div>
                </div>
                
                ${relatedImages.length > 1 ? `
                <div class="detail-section">
                    <h3><i class="fas fa-images"></i> Hình ảnh lễ hội</h3>
                    <div class="image-gallery">
                        ${relatedImages.slice(0, 6).map(img => `
                            <img src="${img}" alt="${festival.name}" class="gallery-image" onclick="openImageModal('${img}')">
                        `).join('')}
                    </div>
                </div>
                ` : ''}
                
                ${festival.schedule ? `
                <div class="festival-schedule">
                    <h3><i class="fas fa-calendar-alt"></i> Lịch trình chi tiết</h3>
                    <div class="schedule-container">
                        ${Object.entries(festival.schedule).map(([day, events]) => `
                            <div class="schedule-day">
                                <h4>${day}</h4>
                                <div class="events-list">
                                    ${events.map(event => `
                                        <div class="event-item">
                                            <span class="event-time">${event.split(' - ')[0]}</span>
                                            <span class="event-desc">${event.split(' - ')[1]}</span>
                                        </div>
                                    `).join('')}
                                </div>
                            </div>
                        `).join('')}
                    </div>
                </div>
                ` : ''}
                
                <div class="festival-info-grid">
                    <div class="info-card venue-card">
                        <h4><i class="fas fa-map-marker-alt"></i> Địa điểm chính</h4>
                        <p>${festival.mainVenue}</p>
                    </div>
                    <div class="info-card significance-card">
                        <h4><i class="fas fa-heart"></i> Ý nghĩa</h4>
                        <p>${festival.significance}</p>
                    </div>
                    <div class="info-card culture-card">
                        <h4><i class="fas fa-gem"></i> Giá trị văn hóa</h4>
                        <p>${festival.culturalValue}</p>
                    </div>
                </div>
                
                ${festival.specialFood ? `
                <div class="festival-food">
                    <h3><i class="fas fa-utensils"></i> Ẩm thực đặc sắc</h3>
                    <div class="food-tags">
                        ${festival.specialFood.map(food => `
                            <span class="food-tag">${food}</span>
                        `).join('')}
                    </div>
                </div>
                ` : ''}
                
                <div class="festival-actions">
                    <button class="btn-primary" onclick="planVisit('${festival.name}')">
                        <i class="fas fa-calendar-plus"></i> Lên kế hoạch tham gia
                    </button>
                    <button class="btn-secondary" onclick="findNearbyHotels('${festival.location}')">
                        <i class="fas fa-bed"></i> Tìm khách sạn gần đây
                    </button>
                    <button class="btn-secondary" onclick="shareFestival('${festival.name}')">
                        <i class="fas fa-share"></i> Chia sẻ
                    </button>
                </div>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
    modal.style.display = 'block';
    document.body.style.overflow = 'hidden';
}

function closeModal() {
    const modal = document.querySelector('.modal');
    if (modal) {
        modal.remove();
    }
}


document.addEventListener('click', function(event) {
    if (event.target.classList.contains('modal')) {
        closeModal();
    }
});


function getCurrentUser() {
    const currentUser = localStorage.getItem('currentUser');
    return currentUser ? JSON.parse(currentUser) : null;
}


function bookHotel(hotelId) {
    const data = loadData();
    const hotel = data.hotels.find(h => h.id === hotelId);
    
    if (!hotel) {
        alert('Không tìm thấy khách sạn!');
        return;
    }
    
    const currentUser = getCurrentUser();
    let name, email;
    
    if (currentUser) {
        name = currentUser.username;
        email = currentUser.email || '';
    } else {
        name = prompt('Họ và tên:');
        if (!name) return;
        
        email = prompt('Email:');
        if (!email) return;
    }
    
    const phone = prompt('Số điện thoại:');
    if (!phone) return;
    
    const checkin = prompt('Ngày nhận phòng (dd/mm/yyyy):');
    if (!checkin) return;
    
    const checkout = prompt('Ngày trả phòng (dd/mm/yyyy):');
    if (!checkout) return;
    
    const rooms = prompt('Số phòng:');
    if (!rooms) return;
    

    const bookings = JSON.parse(localStorage.getItem('hotelBookings') || '[]');
    const booking = {
        id: Date.now(),
        hotelId: hotelId,
        hotelName: hotel.name,
        customerName: name,
        phone: phone,
        email: email,
        checkin: checkin,
        checkout: checkout,
        rooms: parseInt(rooms),
        priceRange: hotel.price,
        bookingDate: new Date().toLocaleDateString('vi-VN'),
        status: 'Đã đặt'
    };
    
    bookings.push(booking);
    localStorage.setItem('hotelBookings', JSON.stringify(bookings));
    
    alert(`Đặt phòng thành công!\n\nKhách sạn: ${hotel.name}\nKhách hàng: ${name}\nSố phòng: ${rooms}\nNhận phòng: ${checkin}\nTrả phòng: ${checkout}\n\nChúng tôi sẽ liên hệ với bạn sớm nhất!`);
}


function viewBookings() {
    const tourBookings = JSON.parse(localStorage.getItem('tourBookings') || '[]');
    const hotelBookings = JSON.parse(localStorage.getItem('hotelBookings') || '[]');
    
    console.log('Tour Bookings:', tourBookings);
    console.log('Hotel Bookings:', hotelBookings);
    
    let message = 'DANH SÁCH ĐẶT CHỖ:\n\n';
    
    if (tourBookings.length > 0) {
        message += '=== TOUR ===\n';
        tourBookings.forEach(booking => {
            message += `${booking.tourName} - ${booking.customerName} - ${booking.phone} - ${booking.date}\n`;
        });
        message += '\n';
    }
    
    if (hotelBookings.length > 0) {
        message += '=== KHÁCH SẠN ===\n';
        hotelBookings.forEach(booking => {
            message += `${booking.hotelName} - ${booking.customerName} - ${booking.phone} - ${booking.checkin}\n`;
        });
    }
    
    if (tourBookings.length === 0 && hotelBookings.length === 0) {
        message += 'Chưa có đặt chỗ nào.';
    }
    
    alert(message);
}

function filterCuisine(category) {
    const data = loadData();
    let filteredCuisine = data.cuisine;
    
    if (category === 'main') {
        filteredCuisine = data.cuisine.filter(f => 
            f.name.includes('Hủ tiếu') || f.name.includes('Cá lóc') || f.name.includes('Lẩu') || f.name.includes('Cơm tấm')
        );
    } else if (category === 'snack') {
        filteredCuisine = data.cuisine.filter(f => 
            f.name.includes('Bánh xèo') || f.name.includes('Bánh tét') || f.name.includes('Bánh chưng')
        );
    } else if (category === 'dessert') {
        filteredCuisine = data.cuisine.filter(f => 
            f.name.includes('Chè') || f.name.includes('Kẹo dừa')
        );
    } else if (category === 'specialty') {
        filteredCuisine = data.cuisine.filter(f => 
            f.name.includes('Nghêu') || f.name.includes('Kẹo dừa') || f.name.includes('Cá lóc')
        );
    }
    
    const container = document.getElementById('cuisineList');
    if (container) {
        container.innerHTML = filteredCuisine.map(food => `
            <div class="card cuisine-card">
                <img src="${food.image}" alt="${food.name}">
                <div class="card-content">
                    <h3>${food.name}</h3>
                    <p>${food.description}</p>
                    <div class="cuisine-meta">
                        <span class="price"><i class="fas fa-tag"></i> ${food.price}</span>
                    </div>
                    <button class="btn-primary" onclick="findRestaurant('${food.name}')">Tìm nhà hàng</button>
                </div>
            </div>
        `).join('');
    }
    
    document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
    event.target.classList.add('active');
}

function findRestaurant(dishName) {
    alert(`Đang tìm nhà hàng phục vụ ${dishName}...`);
    window.location.href = 'nha-hang.html';
}
function closeModal() {
    const modal = document.querySelector('.modal');
    if (modal) {
        modal.remove();
        document.body.style.overflow = 'auto';
    }
}

function openImageModal(imageSrc) {
    const imageModal = document.createElement('div');
    imageModal.className = 'modal image-modal';
    imageModal.innerHTML = `
        <div class="modal-content image-modal-content">
            <span class="close" onclick="closeModal()">&times;</span>
            <img src="${imageSrc}" alt="Hình ảnh chi tiết" class="full-image">
        </div>
    `;
    
    document.body.appendChild(imageModal);
    imageModal.style.display = 'block';
    document.body.style.overflow = 'hidden';
    
    // Click outside to close
    imageModal.addEventListener('click', function(e) {
        if (e.target === imageModal) {
            closeModal();
        }
    });
}

function planVisit(festivalName) {
    alert(`Đang lên kế hoạch tham gia lễ hội "${festivalName}"...\n\nChúng tôi sẽ liên hệ với bạn để tư vấn chi tiết về:\n- Lịch trình tham gia\n- Đặt chỗ ở gần địa điểm\n- Hướng dẫn di chuyển\n- Các hoạt động đặc sắc\n\nHotline: 0336160645`);
}

function findNearbyHotels(location) {
    alert(`Đang tìm khách sạn gần ${location}...`);
    window.location.href = 'khach-san.html';
}

function shareFestival(festivalName) {
    if (navigator.share) {
        navigator.share({
            title: `Lễ hội ${festivalName}`,
            text: `Khám phá lễ hội ${festivalName} tại Du lịch Vĩnh Long`,
            url: window.location.href
        });
    } else {
        const url = window.location.href;
        navigator.clipboard.writeText(url).then(() => {
            alert('Đã sao chép link chia sẻ!');
        });
    }
}

function filterFestivals(category) {
    const data = loadData();
    let filteredFestivals = data.festivals;
    
    if (category === 'khmer') {
        filteredFestivals = data.festivals.filter(f => f.category === 'khmer');
    } else if (category === 'traditional') {
        filteredFestivals = data.festivals.filter(f => f.category === 'traditional');
    } else if (category === 'seasonal') {
        filteredFestivals = data.festivals.filter(f => f.category === 'specialty');
    }
    
    const container = document.getElementById('festivalsList');
    if (container) {
        container.innerHTML = filteredFestivals.map(festival => `
            <div class="card clickable-card festival-card" onclick="showFestivalDetails(${festival.id})">
                <img src="${festival.image}" alt="${festival.name}">
                <div class="card-content">
                    <h3>${festival.name}</h3>
                    <p><i class="fas fa-calendar"></i> ${festival.date}</p>
                    <p><i class="fas fa-map-marker-alt"></i> ${festival.location}</p>
                    <p>${festival.description}</p>
                    <div class="festival-meta">
                        <span class="duration"><i class="fas fa-clock"></i> ${festival.duration}</span>
                        <span class="category"><i class="fas fa-tag"></i> ${getCategoryName(festival.category)}</span>
                    </div>
                    <div class="festival-highlights">
                        <small><strong>Nổi bật:</strong> ${festival.activities.slice(0, 2).join(', ')}...</small>
                    </div>
                    <button class="btn-primary">Xem chi tiết</button>
                </div>
            </div>
        `).join('');
    }
    
    document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
    event.target.classList.add('active');
}

function getCategoryName(category) {
    const categories = {
        'khmer': 'Khmer',
        'traditional': 'Dân gian',
        'specialty': 'Đặc sản'
    };
    return categories[category] || 'Truyền thống';
}
// XÓA CÁC NÚT DỊCH VỤ KHÔNG MONG MUỐN
function removeServiceButtons() {
    // Xóa các nút có text cụ thể
    const buttonsToRemove = [
        'Lên kế hoạch tham gia',
        'Tìm khách sạn gần đây', 
        'Chia sẻ',
        'Lên kế hoạch',
        'Tìm khách sạn',
        'Share'
    ];
    
    buttonsToRemove.forEach(text => {
        const buttons = Array.from(document.querySelectorAll('button, .btn, a'));
        buttons.forEach(btn => {
            if (btn.textContent && btn.textContent.includes(text)) {
                btn.remove();
            }
        });
    });
    
    // Xóa các nút có màu xanh dương
    const blueButtons = document.querySelectorAll('button[style*="background"], .btn[style*="background"]');
    blueButtons.forEach(btn => {
        const style = btn.getAttribute('style') || '';
        if (style.includes('#2c5aa0') || style.includes('rgb(44, 90, 160)')) {
            btn.remove();
        }
    });
    
    // Xóa các container có 3 nút
    const containers = document.querySelectorAll('div');
    containers.forEach(container => {
        const buttons = container.querySelectorAll('button, .btn');
        if (buttons.length === 3) {
            const hasServiceIcons = Array.from(buttons).some(btn => {
                const html = btn.innerHTML;
                return html.includes('fa-calendar') || html.includes('fa-bed') || html.includes('fa-share');
            });
            if (hasServiceIcons) {
                container.remove();
            }
        }
    });
}

// Chạy khi trang load
document.addEventListener('DOMContentLoaded', removeServiceButtons);

// Chạy lại sau 1 giây để bắt các element được thêm sau
setTimeout(removeServiceButtons, 1000);

// Chạy lại khi có thay đổi DOM
const observer = new MutationObserver(removeServiceButtons);
observer.observe(document.body, { childList: true, subtree: true });