
const ADMIN_ACCOUNT = {
    username: 'admin',
    password: 'admin123',
    role: 'admin'
};

function register(username, email, phone, password, confirmPassword) {
    if (password !== confirmPassword) {
        alert('Mật khẩu xác nhận không khớp!');
        return false;
    }
    
    if (password.length < 6) {
        alert('Mật khẩu phải có ít nhất 6 ký tự!');
        return false;
    }
    
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    if (users.find(user => user.username === username)) {
        alert('Tên đăng nhập đã tồn tại!');
        return false;
    }
    
    if (users.find(user => user.email === email)) {
        alert('Email đã được sử dụng!');
        return false;
    }
    
    const newUser = {
        id: Date.now(),
        username: username,
        email: email,
        phone: phone,
        password: password,
        role: 'user',
        createdAt: new Date().toLocaleDateString('vi-VN')
    };
    
    users.push(newUser);
    localStorage.setItem('users', JSON.stringify(users));
    
    alert('Đăng ký thành công! Bạn có thể đăng nhập ngay bây giờ.');
    return true;
}

function login(username, password) {
    // Check admin account
    if (username === ADMIN_ACCOUNT.username && password === ADMIN_ACCOUNT.password) {
        const adminSession = {
            username: ADMIN_ACCOUNT.username,
            role: ADMIN_ACCOUNT.role,
            loginTime: new Date().toISOString()
        };
        localStorage.setItem('currentUser', JSON.stringify(adminSession));
        return { success: true, user: adminSession };
    }
    
    // Check regular users
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    const user = users.find(u => u.username === username && u.password === password);
    
    if (user) {
        const userSession = {
            id: user.id,
            username: user.username,
            email: user.email,
            phone: user.phone,
            role: user.role,
            loginTime: new Date().toISOString()
        };
        localStorage.setItem('currentUser', JSON.stringify(userSession));
        return { success: true, user: userSession };
    }
    
    return { success: false, message: 'Tên đăng nhập hoặc mật khẩu không đúng!' };
}

function logout() {
    console.log('🚪 Đăng xuất...');
    
    try {
        localStorage.removeItem('currentUser');
        console.log('✅ Đã xóa currentUser khỏi localStorage');
        
        alert('✅ Đã đăng xuất thành công!');
        console.log('🔄 Chuyển hướng về trang chủ...');
        
        window.location.href = 'index.html';
    } catch (error) {
        console.error('❌ Lỗi khi đăng xuất:', error);
        alert('Có lỗi khi đăng xuất, nhưng sẽ chuyển về trang chủ');
        window.location.href = 'index.html';
    }
}

function getCurrentUser() {
    try {
        const userStr = localStorage.getItem('currentUser');
        if (!userStr) {
            console.log('👤 Không có user trong localStorage');
            return null;
        }
        
        const user = JSON.parse(userStr);
        console.log('👤 Current user từ localStorage:', user);
        return user;
    } catch (error) {
        console.error('❌ Lỗi khi lấy current user:', error);
        return null;
    }
}

function isAdmin() {
    const user = getCurrentUser();
    return user && user.role === 'admin';
}

function requireAdmin() {
    if (!isAdmin()) {
        alert('Bạn cần đăng nhập với quyền admin để truy cập trang này!');
        window.location.href = 'dang-nhap.html';
        return false;
    }
    return true;
}

function updateNavigation() {
    console.log('🔄 Cập nhật navigation...');
    
    const user = getCurrentUser();
    console.log('👤 User cho navigation:', user);
    
    const navMenu = document.querySelector('.nav-menu');
    
    if (!navMenu) {
        console.log('⚠️ Không tìm thấy nav-menu');
        return;
    }
    
    // Remove existing auth links
    const existingAuthLinks = navMenu.querySelectorAll('.auth-link');
    console.log('🗑️ Xóa', existingAuthLinks.length, 'auth links cũ');
    existingAuthLinks.forEach(link => link.remove());
    
    if (user) {
        console.log('✅ User đã đăng nhập - thêm account và logout links');
        
        // User is logged in - show account and logout
        const accountLi = document.createElement('li');
        accountLi.className = 'auth-link';
        accountLi.innerHTML = `<a href="tai-khoan.html"><i class="fas fa-user"></i> ${user.username}</a>`;
        navMenu.appendChild(accountLi);
        
        // Add logout button to navigation
        const logoutLi = document.createElement('li');
        logoutLi.className = 'auth-link';
        logoutLi.innerHTML = `<a href="#" onclick="logout(); return false;" style="color: #ff6b6b; background: rgba(255, 107, 107, 0.1); padding: 8px 12px; border-radius: 5px; font-weight: bold;"><i class="fas fa-sign-out-alt"></i> Đăng xuất</a>`;
        navMenu.appendChild(logoutLi);
        
        if (user.role === 'admin') {
            console.log('👑 Thêm admin link');
            const adminLi = document.createElement('li');
            adminLi.className = 'auth-link';
            adminLi.innerHTML = `<a href="admin.html" style="color: #ffd700;"><i class="fas fa-cog"></i> Admin</a>`;
            navMenu.appendChild(adminLi);
        }
    } else {
        console.log('⚠️ User chưa đăng nhập - thêm login và register links');
        
        // User is not logged in - show login and register
        const loginLi = document.createElement('li');
        loginLi.className = 'auth-link';
        loginLi.innerHTML = `<a href="dang-nhap.html"><i class="fas fa-sign-in-alt"></i> Đăng nhập</a>`;
        navMenu.appendChild(loginLi);
        
        const registerLi = document.createElement('li');
        registerLi.className = 'auth-link';
        registerLi.innerHTML = `<a href="dang-ky.html"><i class="fas fa-user-plus"></i> Đăng ký</a>`;
        navMenu.appendChild(registerLi);
    }
    
    console.log('✅ Hoàn thành cập nhật navigation');
}

// Call updateNavigation on page load
if (typeof document !== 'undefined') {
    document.addEventListener('DOMContentLoaded', function() {
        updateNavigation();
    });
}